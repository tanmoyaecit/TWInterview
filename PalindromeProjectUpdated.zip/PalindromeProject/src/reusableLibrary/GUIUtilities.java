package reusableLibrary;

public class GUIUtilities {

	waitandCLick(){
		driver.findElementbyXPath("loginLocator_usrname").wait(untilElementis visible);
		driver.findElement.click();
	}
}
