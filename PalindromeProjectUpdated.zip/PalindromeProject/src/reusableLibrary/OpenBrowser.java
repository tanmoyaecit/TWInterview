package reusableLibrary;

import FunctionalTestCases.ChromeDriver;
import FunctionalTestCases.Driver;

public class OpenBrowser {
	System.setproperty("","");
	Driver driver = new ChromeDriver();
	return driver;
}
