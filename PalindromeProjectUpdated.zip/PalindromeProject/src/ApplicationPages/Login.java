package ApplicationPages;
import reusableLibrary.GUIUtilities;
public class Login {

	 public login(driver) {
		 this.driver= driver;
		 //Enter Username
		 driver.findelmentbyXPATH("xpath").sendkeys("Username");
		//Enter Password
		 driver.findelmentbyXPATH("xpath").sendkeys("Password");
		 // click submit
		 waitandCLick();
		 
	 }
}
