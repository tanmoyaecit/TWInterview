package ApplicationPages;

public class CheckOut {

	search(driver, String searchIteam){
		driver.findElementbyID("").sendkeys("searchIteam");
								.click();
		
		list = driver.findelmentsbytagname("name");
		 while(list.next()) {
			String product = driver.findelementbytagnme().getText();
			
			if(product.equalsIgnoreCase("Iphone12 Blue")) {
				
				for(int i=0; i<=ouantity; i++) {
				element.click();
				}
			}
			 
		 }
		 
		 checkout.click();
	}
}
