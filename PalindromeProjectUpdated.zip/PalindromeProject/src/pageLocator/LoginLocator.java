package pageLocator;

public class LoginLocator {
	
	public static String loginLocator_usrname = "*//input[@id='username']"

}
