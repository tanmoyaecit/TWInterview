package pageLocator;

public class CHeckOutLocator {

}
