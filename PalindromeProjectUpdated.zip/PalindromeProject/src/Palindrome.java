
public class Palindrome {
	
	public String reverse(String str) {
		String rev ="";
		for(int i = str.length()-1 ; i >=0 ; i--) {
			rev = rev + str.charAt(i);
		}
		System.out.println("Reverse String "+rev);
		return rev;
	}
	
	public void checkPalinDrome(String str) {
		if(str.equals(reverse(str))) {
			System.out.println("Provided String is palindrome");
		}
		else {
			System.out.println("Provided String is not Palindrome");
		}
		
	}
	
	public String inputString(int wLength,int aLength,int dLength,int sLength ) {
			String totalWord = "";
			while(wLength > 0) {
				for(int k =0 ; k<aLength; k++) {
					totalWord = totalWord +"A";
				}
				for(int l =0; l< dLength; l++) {
					totalWord=totalWord+"0";
				}
				for(int m = 0; m<sLength;m++) {
					totalWord = totalWord+"*";
				}
					
				wLength = wLength + 1;
			}
			
			return totalWord;
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Palindrome p = new Palindrome();
		//p.reverse("ABAC");
		int wordLength = 6;
		int alphaNumer =4;
		int digits = 2;
		int specialChar =0;
		String word = p.inputString(wordLength,alphaNumer,digits,specialChar);
		System.out.println("Given String "+word);
		//p.checkPalinDrome(word);
		
		

	}

}
