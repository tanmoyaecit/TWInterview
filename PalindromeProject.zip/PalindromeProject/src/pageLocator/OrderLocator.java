package pageLocator;

public class OrderLocator {

}
