package pageLocator;

public class LoginLocator {

}
