package FunctionalTestCases;

public class PurchaseProduct {

	
	driver = openBrowser();
	//Login the pages
	Login.login (driver);
	//Search Product
	CheckOut.Search(driver, "Ihone12");
	order.Order(river, "name", "Mobile", "Address");
	
	
}
