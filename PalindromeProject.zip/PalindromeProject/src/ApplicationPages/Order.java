package ApplicationPages;

public class Order {

	Order(driver, String Name, String Mobile, String Address){
		driver.findElement(By.XPath("Name XPATH")).sendkeys(Name);
		driver.findElement(By.XPath("Mobile XPATH")).sendkeys(Mobile);
		driver.findElement(By.XPath("Address XPATH")).sendkeys(Address);
		
		//Submit
		driver.findElement(By.XPath("Submit XPATH")).click();
		
		//OTP
		enterOTP();
		//PAY
		driver.findElement(By.XPath("PAY XPATH")).click();
		
	}
	
	enterOTP(){
		driver.findElement(By.XPath("OTP XPATH")).sendkeys("Static OTP");
	}
}
